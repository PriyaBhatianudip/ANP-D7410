package com.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@NoArgsConstructor
@Getter
@Setter
@ToString
@Entity
public class User {
	@Id
	private int id;
	private String name;
	private double phone;
	private String email;
	private String password;
	private String address;
	private String department;
	public User(int id, String name, double phone, String email, String password, String address, String department) {
		super();
		this.id = (int) Math.random()* 1000;
		this.name = name;
		this.phone = phone;
		this.email = email;
		this.password = password;
		this.address = address;
		this.department = department;
	}
	
	
}
