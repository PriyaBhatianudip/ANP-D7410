package Utilities;

import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.entity.User;

public class Userutilities {
	
	SessionFactory factory = new Configuration().configure("hibernate.cfg.xml").buildSessionFactory();
	
	Session s = factory.openSession();
	
	Transaction tx = s.beginTransaction();
	
	 Scanner sc = new Scanner(System.in);
	
		public  User RegisterUser() {
			User user = new User();
			
			System.out.println("enter user name: ");
			user.setName(sc.nextLine());
			System.out.println("enter user phone: ");
			user.setPhone(sc.nextDouble());
			sc.nextLine();
			System.out.println("enter user address: ");
			user.setAddress(sc.nextLine());
			System.out.println("enter user email: ");
			user.setEmail(sc.nextLine());
			System.out.println("enter password: ");
			user.setPhone(sc.nextDouble());
			sc.nextLine();
			System.out.println("enter user department: ");
			sc.nextLine();
			
			s.persist(user);
			return user;
		}
		
		public void findUser() {
			System.out.println("enter id of user: ");
			int id = sc.nextInt();

			User u = s.find(User.class, id);

			if (u != null) {
				System.out.println("user name:" + u.getName() + " || user phone: " + u.getPhone() + " || user address: "
						+ u.getAddress() + " || user email: " + u.getEmail() + " || user department: "
						+ u.getDepartment());
				
				System.out.println("user found!");
			}else {
				System.out.println("user not found");
			}
			

		}
		
		public void getAllUsers() {
			
		}
		
		public int updateUser() {
			System.out.println("enter id of user: ");
			int id = sc.nextInt();
			return id;
		}
		
		public int deleteUser() {
			System.out.println("enter id of user: ");
			int id = sc.nextInt();
			return id;
		}
}
